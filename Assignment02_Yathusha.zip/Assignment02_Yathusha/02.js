function AddFunction() {
var check = /^[A-Za-z ]+$/;
var check1 = check.test(document.getElementById("moviename").value[0]);
var check2 = document.getElementById("moviename").value;

     if (!check1) {

            document.getElementById("Demo").innerHTML="Invalid TV Show Name";
            Demo.classList.remove('valid');
            Demo.classList.add('invalid');
        }

      else{

            document.getElementById("Demo").innerHTML= check2 + " has been added"
            Demo.classList.remove('invalid');
            Demo.classList.add('valid');
        }
return check1;
    }
