var details = {
  users: [{
    email: "thaura@gmail.com",
    password: "thau"
  }, {
    email: "yathusha@gmail.com",
    password: "yathu"
  }, {
    email: "rathika@gmail.com",
    password: "rathi"
  }, {
    email: "umaliny@gmail.com",
    password: "uma"
  }, {
    email: "kaishika@gmail.com",
    password: "kaishi"
  }],
  addUser: function() {
    var email = document.getElementById('email').value
    var password = document.getElementById('password').value
    var check = this.users.some(function(e) {
        return e.email == email && e.password == password
    })

    document.getElementById('demo').innerHTML = check ? "<span style='color:green'>" +"Successful" : "<span style='color:red'>" +"Unsuccessful";
  }
};

document.getElementById("Button").addEventListener("click", details.addUser.bind(details));
